from flask import Flask, jsonify, request
import firebase_admin
from firebase_admin import credentials, firestore




# initialise firebase
cred = credentials.Certificate('social-project-144e7-firebase-adminsdk-v85r4-8f4d33c2d5.json')
firebase_admin.initialize_app(cred)

db = firestore.client()

# -------------- FIREBASE REFERENCES -----------------
userRef = db.collection('Users')




app = Flask(__name__)

# create user code
# User Details needed:
# id, number, name, email, dob, year group, major, campus residence?, best food, best movie


@app.route('/Users', methods=['POST'])
def createUser():
    email = request.json['email']
    user = {
        'userID': request.json['userID'],
        'phoneNumber': request.json['phoneNumber'],
        'email': request.json['email'],
        'dateOfBirth': request.json['dateOfBirth'],
        'userName': request.json['userName'],
        'campusResidence': request.json['campusResidence'],
        'yearGroup': request.json['yearGroup'],
        'major': request.json['major'],
        'favFood': request.json['favFood'],
        'favMovie': request.json['favMovie'],
    }
    # check if user exists
    if userRef.document(email).get().exists:
        return jsonify({'message':'User Already exists'}), 404
   


    # if user does not exist create new user
    
        # create user in firestore
    userRef.document(email).set(user)
    return jsonify({'user': 'user created'}), 201

    
        # return jsonify({'message': 'Something went wrong'}), 404,



# Get user details 
@app.route('/Users/<userEmail>', methods=['GET'])
def getUserDetails(userEmail):
    email = str(userEmail)
    # get user account and check whether it exists
    userAccount = userRef.document(email).get()
    if not userAccount.exists:
        return jsonify({'message':'Account does not exist'}), 404
    
    # if user exists return their details
    # user = UserModel(
    #         userID=data['userID'],
    #         phoneNumber= data['phoneNumber'],
    #         dateOfBirth=data['dateOfBirth'],
    #         email=data['email'],
    #         yearGroup=data['yearGroup'],
    #         campusResidence=data['campusResidence'],
    #         favFood=data['favFood'],
    #         favMovie=data['favMovie']
    #     )
    userInfo = userAccount.to_dict()
    return jsonify(userInfo), 201


# update user details
@app.route('/Users/<userEmail>', methods=['PUT'])
def updateUserDetails(userEmail):
    email = str(userEmail)
    
    # collect user data
    data = request.json

    if not userRef.document(email).get().exists:
        return jsonify({'User not found'}), 400

    # Update user in firestore 

    userRef.document(email).update(data)
    return jsonify({'Updated Successfully'}), 201



if __name__ == '__main__':
    app.run()
