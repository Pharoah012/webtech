import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:webtech_project/constants.dart';
import 'package:webtech_project/widgets/customTabItem.dart';
import 'package:webtech_project/widgets/customText.dart';


var apiUrl = 'http://127.0.0.1:5000/Users';

class PostModel{
  final String postID;
  final String userEmail;
  final String message;
  final DateTime timeStamp;



 PostModel({
  required this.postID,
  required this.userEmail,
  required this.message,
  required this.timeStamp,

});

factory PostModel.fromJson(Map<String, dynamic> json){
  return PostModel(
    postID: json['postID'], 
    userEmail: json['userEmail'], 
    message: json['message'], 
    timeStamp: json['timeStamp']
    );
}

  Map<String, dynamic> toMap() {
    return {
      'userEmail': userEmail,
      'message': message,
      'timeStamp': timeStamp,
      'postID': postID,
    };
  }

// create post 
Future <void> createtUserPost(context) async {
 var response = await http.post(
  Uri.parse(apiUrl),
  headers: 
    <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    
  },
  body: jsonEncode(toMap())
  );
   print(response.statusCode);
  if(response.statusCode != 201){
 
   AlertDialog(
    title: CustomText(
      text: 'SuccessFul',
      color: kPrimary,),);
  
  }
  else{
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: CustomText(
            text: 'Please try again',)));

  }
 

}











  Future<PostModel> getUserPosts(userEmail) async {
   var response = await http.get(
    Uri.parse('$apiUrl/$userEmail'),
    headers:  <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    
    },
    
    );


   if(response.statusCode == 201){
    final data = json.decode(response.body);
    final user = PostModel.fromJson(data);
    return user;
   }
   else{
    throw Exception('Sth went Wrong');
   }

  }
}
