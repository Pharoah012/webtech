from flask import Flask, jsonify, request
import firebase_admin
from firebase_admin import credentials, firestore



# initialise firebase
cred = credentials.Certificate('social-project-144e7-firebase-adminsdk-v85r4-8f4d33c2d5.json')
firebase_admin.initialize_app(cred)

db = firestore.client()

# -------------- FIREBASE REFERENCES -----------------
postRef = db.collection('Posts')



app = Flask(__name__)

# create post code
# Post Details needed:
# id, email, message, email, timestamp

@app.route('/Posts', methods=['POST'])
def createPost():
    post = {
        'PostId': request.json['postID'],
        'userEmail': request.json['userEmail'],
        'message': request.json['message'],
        'timeStamp': request.json['timeStamp'],
        
       
    }
    postID = request.json['postID']

#  Create new post in firestore
    postRef.document(postID).set(post)
    return jsonify({'user': 'post created'}), 201





# Get all post details 
@app.route('/Posts', methods=['GET'])
def getPostDetails():
    posts = postRef.get()

    posts = [doc.to_dict() for doc in posts]
    return jsonify(posts), 201



# Get post details of user
@app.route('/Posts/<userEmail>', methods=['GET'])
def getUserPostDetails(userEmail):
    email = str(userEmail)
    # get user account and check whether it exists
    posts = postRef.where('userEmail', '==', email).stream()

    posts = [doc.to_dict() for doc in posts]
    return jsonify(posts), 201


# delete user post
@app.route('/Posts/<postID>', methods=['DELETE'])
def deletePost(postID):
    postid = str(postID)
    if not postRef.document(postid).get().exists:
        return jsonify({'error': 'user not found'}), 404

    # Delete user   
    postRef.document(postid).delete()
    return jsonify({'message': 'Post successful Deleted'})
  
if __name__ == '__main__':
    app.run()
